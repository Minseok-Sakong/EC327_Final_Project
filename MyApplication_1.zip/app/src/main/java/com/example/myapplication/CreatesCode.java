package com.example.myapplication;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

//takes to user to this activity if they want to create a new meeting ID

public class CreatesCode extends Activity {

    private TextView code_text;
    private Button confirm_details;
    private EditText enter_code;
    private EditText enter_name;
    private String your_code;
    private String your_name;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.createscode);

        //creates a random and unique meeting ID
        SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmssMMyy", Locale.getDefault());
        sdf.setTimeZone(TimeZone.getTimeZone("EST"));
        String currentDateandTime = sdf.format(new Date());
        long temp = Long.parseLong(currentDateandTime);
        String theCode = Long.toHexString(temp);

        code_text=findViewById(R.id.group_code_message);
        confirm_details=findViewById(R.id.button5);
        enter_code=findViewById(R.id.enter_code);
        enter_name=findViewById(R.id.enter_name);
        enter_code.setText(theCode);

        confirm_details.setOnClickListener(v -> {
            your_code=enter_code.getText().toString();
            your_name=enter_name.getText().toString();

            //checks if the user enters a meeting name
            if( your_name.equals(""))
                Toast.makeText(getApplicationContext(), "Please enter Meeting Name", Toast.LENGTH_LONG).show();


            else
            {
                //copies the random Meeting ID to the clipboard of the phone
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText(null, theCode);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getApplicationContext(), "Your group code has been copied to the clipboard", Toast.LENGTH_LONG).show();
                //creates the child in the database for this new meeting_id and creates two children under the meeting_id
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference();
                myRef.child(your_code).child("MEETING_ID").setValue(your_code);
                myRef.child(your_code).child("MEETING_NAME").setValue(your_name);

                //Moves to the Activity_layout activity and passes the meeting ID and meeting name to that activity
                Intent intent = new Intent(CreatesCode.this, Activity_list.class);
                intent.putExtra("meeting_id", your_code);
                intent.putExtra("meeting_name", your_name);
                startActivity(intent);
                finish();
            }
        });

    }
}