package com.example.myapplication;

//A class that has two private string members
//Functions that can get the values of the private members
public class SampleData {

    private String avail_date;
    private String avail_time;

    public SampleData(String avail_date, String avail_time)
    {

        this.avail_date = avail_date;
        this.avail_time = avail_time;
    }


    public String getAvail_Date()
    {
        return this.avail_date;
    }

    public String getAvail_Time()
    {
        return this.avail_time;
    }
}